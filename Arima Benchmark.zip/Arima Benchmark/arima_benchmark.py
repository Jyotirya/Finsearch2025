import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error

df = pd.read_csv("/content/NIFTY100 Train Data.csv")
df.columns = df.columns.str.strip()
close_prices = df['Close']
log_close = np.log(close_prices)

plt.figure(figsize=(10,4))
plt.plot(log_close)
plt.title("The log of closing prices")
plt.show()

trainseries = log_close.copy()
d = 0
while True:
    p_value = adfuller(trainseries)[1]
    if p_value < 0.05:
        break
    trainseries = trainseries.diff().dropna()
    d += 1
print(f"Final differencing order (d): {d}")

plt.figure(figsize=(12,6))
plt.subplot(121)
plot_acf(trainseries, ax=plt.gca(), lags=30)
plt.title("ACF")
plt.subplot(122)
plot_pacf(trainseries, ax=plt.gca(), lags=30)
plt.title("PACF")
plt.show()

model = ARIMA(log_close, order=(1, d, 2))
model_fit = model.fit()
print(model_fit.summary())

df_test = pd.read_excel("/content/NIFTY100 Test Data.xlsx")
df_test.columns = df_test.columns.str.strip()
test_close = df_test['Close']
log_test_close = np.log(test_close)

history = list(log_close)
predictions_log = []
for t in range(len(log_test_close)):
    model = ARIMA(history, order=(1, d, 2))
    model_fit = model.fit()
    yhat_log = model_fit.forecast()[0]
    predictions_log.append(yhat_log)
    history.append(log_test_close.iloc[t])

forecast = np.exp(predictions_log)

actual = test_close.values
rmse = np.sqrt(mean_squared_error(actual, forecast))
mae  = mean_absolute_error(actual, forecast)
mape = np.mean(np.abs((actual - forecast) / actual)) * 100
print(f"RMSE: {rmse:.2f}")
print(f"MAE : {mae:.2f}")
print(f"MAPE: {mape:.2f}%")

ratios = [forecast[i+1] / test_close.iloc[i] for i in range(len(test_close)-1)]
print("Min ratio:", min(ratios))
print("Max ratio:", max(ratios))

initial_capital = 100000.0
cash = initial_capital
position = 0
portfolio_values = []
trade_dates = []
trade_signals = []

forecast_series = pd.Series(forecast, index=df_test.index)

BUY_THRESHOLD  = 1.00005
SELL_THRESHOLD = 0.99995

print("\nDate    Price    Forecast   Ratio   Signal     Cash   Position")
print("--------------------------------------------------------------")
for i, date in enumerate(df_test.index[:-1]):
    price_today     = test_close.iloc[i]
    price_next_pred = forecast_series.iloc[i+1]
    ratio           = price_next_pred / price_today

    signal = 0
    if ratio > BUY_THRESHOLD:
        if cash > 0:
            position = cash/ price_today
            cash = 0
        signal = +1
    elif ratio < SELL_THRESHOLD:
        if position > 0:
            cash = position * price_today
            position = 0
        signal = -1

    print(f"{date:2}   {price_today:8.2f}   {price_next_pred:8.2f}  "
          f"{ratio:7.4f}   {signal:6d}  {cash:10.2f}  {position:9.4f}")

    trade_signals.append(signal)
    trade_dates.append(date)
    portfolio_values.append(cash + position * price_today)

final_date = df_test.index[-1]
final_value = cash + position * test_close.iloc[-1]
trade_dates.append(final_date)
portfolio_values.append(final_value)

portfolio_series = pd.Series(portfolio_values, index=trade_dates)

buys  = [trade_dates[i] for i, sig in enumerate(trade_signals) if sig == +1]
sells = [trade_dates[i] for i, sig in enumerate(trade_signals) if sig == -1]

plt.figure(figsize=(14,8))
plt.subplot(2,1,1)
plt.plot(portfolio_series, color='blue', label='Portfolio Value')
plt.title('Portfolio Value Over 6 Weeks')
plt.ylabel('Portfolio Value (Rs)')
plt.legend()

plt.subplot(2,1,2)
plt.plot(df_test.index, test_close,    color='black', label='Close Price')
plt.plot(df_test.index, forecast,       color='green', label='Forecast')
plt.scatter(buys,  test_close.loc[buys],  marker='^', color='green', label='Buy')
plt.scatter(sells, test_close.loc[sells], marker='v', color='red',   label='Sell')
plt.title('Price vs Forecast with Trade Signals')
plt.xlabel('Date')
plt.ylabel('Price (Rs)')
plt.legend()

plt.tight_layout()
plt.show()

perf = pd.DataFrame({
    'Portfolio': portfolio_series
})
perf['Returns'] = perf['Portfolio'].pct_change().fillna(0)

cumulative_return = perf['Portfolio'].iloc[-1] / perf['Portfolio'].iloc[0] - 1

annual_volatility = perf['Returns'].std() * np.sqrt(252)

risk_free_rate = 0.05
daily_rf = (1 + risk_free_rate)(1/252) - 1
excess_returns = perf['Returns'] - daily_rf
sharpe_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(252)

rolling_max = perf['Portfolio'].cummax()
drawdown = perf['Portfolio'] / rolling_max - 1
max_drawdown = drawdown.min()

print("Performance Summary")
print(f"Cumulative Return   : {cumulative_return:.2%}")
print(f"Annual Volatility   : {annual_volatility:.2%}")
print(f"Sharpe Ratio        : {sharpe_ratio:.2f}")
print(f"Max Drawdown        : {max_drawdown:.2%}")

import matplotlib.pyplot as plt

plt.figure(figsize=(14,8))

plt.subplot(2,1,1)
plt.plot(perf['Returns'], color='blue')
plt.title('Daily Portfolio Returns')
plt.ylabel('Return')
plt.axhline(0, color='black', linewidth=0.5)

plt.subplot(2,1,2)
plt.plot(drawdown, color='red')
plt.title('Portfolio Drawdown')
plt.ylabel('Drawdown')
plt.axhline(0, color='black', linewidth=0.5)

plt.tight_layout()
plt.show()